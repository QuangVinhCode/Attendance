package com.vn.edu.attendance_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendanceBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendanceBeApplication.class, args);
	}

}
