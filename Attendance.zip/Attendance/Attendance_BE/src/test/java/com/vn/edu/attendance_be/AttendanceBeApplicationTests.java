package com.vn.edu.attendance_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendanceBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
