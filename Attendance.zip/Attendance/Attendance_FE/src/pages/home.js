import React from "react";
import AuthService from "../services/auth.service";
import CardClass from "../components/CardClass";
import Header from "../components/Header";

const Home = () => {
    const profile = AuthService.getUserInfo();
    console.log(profile);
    return (
        <>
            <Header />
            <div className="flex flex-col  bg-gray-500 items-center min-h-screen justify-center">
                <div className="absolute  opacity-80  z-0"></div>

                <CardClass />
                <CardClass />
                <CardClass />
                <CardClass />
            </div>
        </>
    );
};

export default Home;
