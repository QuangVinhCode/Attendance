const KEY_LOCAL = "__AUTH__";
export default class AuthService {
    static isLogin() {
        return localStorage.getItem(KEY_LOCAL) !== null;
    }

    static getUserInfo() {
        try {
            return JSON.parse(localStorage.getItem(KEY_LOCAL));
        } catch (error) {
            return null;
        }
    }

    static logout() {
        return localStorage.removeItem(KEY_LOCAL);
    }

    static setProfile(data) {
        return localStorage.setItem(KEY_LOCAL, JSON.stringify(data));
    }

    static Login(email, password) {
        AuthService.setProfile({ email, password });
    }
}
