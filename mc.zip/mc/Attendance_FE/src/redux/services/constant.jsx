export const API_CLASS = "http://localhost:8080/api/v1/classes";

export const API_SUBJECT = "http://localhost:8080/api/v1/subjects";

export const API_LESSON = "http://localhost:8080/api/v1/lessons";

export const API_ACCOUNT = "http://localhost:8080/api/v1/accounts";

export const API_EXERCISE = "http://localhost:8080/api/v1/exercises";